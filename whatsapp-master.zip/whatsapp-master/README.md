# Whatsapp Web - Frontend
The frontend of the Whatsapp Web chat app is built using Bootstrap. It also has contains design to edit profile, send chat messages (client only, no server) and display notifications for unread messages.

[Click Here](https://anishghosh103.github.io/whatsapp) to check the website.